package com.optum.cp;

import com.optum.cp.service.MigrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@Slf4j
@RequiredArgsConstructor
public class IbrCpDbFlywayApplication implements CommandLineRunner {

	private final MigrationService migrationService;

	public static void main(String[] args) {
		SpringApplication.run(IbrCpDbFlywayApplication.class, args);

		try {
			// Keep the application running
			Thread.currentThread().join();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public void run(String... args) throws Exception {
		log.info("Starting database migration...");
		String command = args.length > 0 ? args[0] : "unknown";
		switch (command) {
			case "info":
				migrationService.infoMigration();
				break;
			case "repair":
				migrationService.repairMigration();
				break;
			case "validate":
				migrationService.validateMigration();
				break;
			case "baseline":
				migrationService.baselineMigration();
				break;
			case "clean":
				migrationService.cleanMigration();
				break;
			case "migrate":
				migrationService.migrateDatabase();
				break;
			default:
				log.info("Unknown command. Available commands: migrate, info, repair, validate, baseline, clean");
		}
		log.info("Database migration completed.");
	}

}
