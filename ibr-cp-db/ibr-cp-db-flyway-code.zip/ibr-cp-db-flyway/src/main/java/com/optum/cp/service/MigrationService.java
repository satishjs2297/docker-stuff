package com.optum.cp.service;

public interface MigrationService {

    void migrateDatabase();

    void infoMigration();

    void repairMigration();

    void validateMigration();

    void baselineMigration();

    void cleanMigration();

}
