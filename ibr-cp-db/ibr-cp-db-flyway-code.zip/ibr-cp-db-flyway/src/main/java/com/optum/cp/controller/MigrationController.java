package com.optum.cp.controller;

import com.optum.cp.service.MigrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/migration")
@Tag(name = "DB Migration API", description = "Operations related to Migration")
@RequiredArgsConstructor
@Slf4j
public class MigrationController {

    private final MigrationService migrationService;

    @GetMapping("/migrate")
    @Operation(summary = "Migrate Database", description = "Triggers the database migration process.")
    public ResponseEntity<String> migrateDatabase() {
        log.info("Starting database migration...");
        migrationService.migrateDatabase();
        return ResponseEntity.ok("Database migration completed.");
    }

    @GetMapping("/info")
    @Operation(summary = "Migration Info", description = "Fetches information about the current migration state.")
    public ResponseEntity<String> infoMigration() {
        log.info("Fetching migration info...");
        migrationService.infoMigration();
        return ResponseEntity.ok("Migration info fetched.");
    }

    @GetMapping("/repair")
    @Operation(summary = "Repair Migration", description = "Repairs the migration state.")
    public ResponseEntity<String> repairMigration() {
        log.info("Repairing migration...");
        migrationService.repairMigration();
        return ResponseEntity.ok("Migration repaired.");
    }

    @GetMapping("/validate")
    @Operation(summary = "Validate Migration", description = "Validates the migration state.")
    public ResponseEntity<String> validateMigration() {
        log.info("Validating migration...");
        migrationService.validateMigration();
        return ResponseEntity.ok("Migration validated.");
    }

    @GetMapping("/baseline")
    @Operation(summary = "Baseline Migration", description = "Sets a baseline for the migration.")
    public ResponseEntity<String> baselineMigration() {
        log.info("Base lining migration...");
        migrationService.baselineMigration();
        return ResponseEntity.ok("Migration baselined.");
    }

    @GetMapping("/clean")
    @Operation(summary = "Clean Migration", description = "Cleans the migration state.")
    public ResponseEntity<String> cleanMigration() {
        log.info("Cleaning migration...");
        migrationService.cleanMigration();
        return ResponseEntity.ok("Migration cleaned.");
    }

}
