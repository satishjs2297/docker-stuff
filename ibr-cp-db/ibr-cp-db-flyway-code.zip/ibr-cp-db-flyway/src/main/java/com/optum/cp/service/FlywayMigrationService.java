package com.optum.cp.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.flywaydb.core.Flyway;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class FlywayMigrationService implements MigrationService {

    private final Flyway flyway;

    @Override
    public void migrateDatabase() {
        log.info("Starting database migration...");
        flyway.migrate();
    }

    @Override
    public void infoMigration() {
        log.info("Fetching migration info...");
        flyway.info();
    }

    @Override
    public void repairMigration() {
        log.info("Repairing migration...");
       flyway.repair();
    }

    @Override
    public void validateMigration() {
        log.info("Validating migration...");
       flyway.validate();
    }

    @Override
    public void baselineMigration() {
        log.info("Base lining migration...");
        flyway.baseline();
    }

    @Override
    public void cleanMigration() {
        log.info("Cleaning migration...");
        flyway.clean();
    }
}
