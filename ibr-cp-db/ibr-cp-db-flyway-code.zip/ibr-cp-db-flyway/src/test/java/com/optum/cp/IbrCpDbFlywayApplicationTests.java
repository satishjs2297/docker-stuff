package com.optum.cp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbrCpDbFlywayApplicationTests {

	@Test
	void contextLoads() {
	}

}
